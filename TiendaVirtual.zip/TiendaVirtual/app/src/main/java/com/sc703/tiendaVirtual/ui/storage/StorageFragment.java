package com.sc703.tiendaVirtual.ui.storage;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.sc703.tiendaVirtual.R;

import java.io.File;
import java.io.IOException;

import static android.app.Activity.RESULT_OK;

public class StorageFragment extends Fragment {

    StorageReference storageReference;
    ImageView iv_Imagen;
    EditText et_NombreIMG;
    Button bn_Descarga, bn_Carga, bn_Buscar;
    Uri imagenURI;
    Integer Codigo = 123;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_storage, container, false);

        et_NombreIMG = root.findViewById(R.id.et_IMGNombre);
        iv_Imagen = root.findViewById(R.id.iv_Imagen);

        bn_Buscar = root.findViewById(R.id.bn_Busqueda);
        bn_Carga = root.findViewById(R.id.bn_Cargar);
        bn_Descarga = root.findViewById(R.id.bn_Descargar);

        bn_Buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BuscarImagen(getView());
            }
        });

        bn_Descarga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DescargarImagen();
            }
        });

        bn_Carga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CargarImagen(getView());
            }
        });
        return root;
    }

    private void BuscarImagen(View view) {
        Intent intent = new Intent();
        intent.setType("Image/*");
        intent.setAction(intent.ACTION_GET_CONTENT);
        startActivityForResult(intent.createChooser(intent, "Seleccione una Imagen"), Codigo);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Codigo && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imagenURI = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imagenURI);
                iv_Imagen.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getContext(), "Imagen no encontrada", Toast.LENGTH_SHORT);
            }
        }
    }

    private String ObtenerExtension(Uri uri) {
        ContentResolver contentResolver = getActivity().getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));

    }

    private void CargarImagen(View view) {
        storageReference = FirebaseStorage.getInstance().getReference().child("Imagenes");

        if (imagenURI != null) {
            final ProgressDialog dialog = new ProgressDialog(getActivity());
            dialog.setTitle("Cargando la Imagen");
            dialog.show();

            StorageReference ref = storageReference.child(et_NombreIMG.getText().toString() + ObtenerExtension(imagenURI));
            ref.putFile(imagenURI)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            dialog.dismiss();
                            Toast.makeText(getContext(), "Imagen Cargada Exitosamente", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            dialog.dismiss();
                            Toast.makeText(getContext(), "La imagen no se pudo  cargar", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                            Long progreso = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                            dialog.setMessage("Cargado " + progreso + "%");
                        }
                    });
        } else {
            Toast.makeText(getContext(), "Debe seleccionar una imagen", Toast.LENGTH_SHORT).show();
        }
    }

    private void DescargarImagen() {
        storageReference = FirebaseStorage.getInstance().getReference().child("Imagenes/" + et_NombreIMG.getText().toString());

        File temporal = null;
        try {
            temporal = File.createTempFile("imagen", "jpg");
        } catch (IOException e) {
            e.printStackTrace();
        }
        final File ArchivoFinal = temporal;

        storageReference.getFile(temporal)
                .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                        String url = ArchivoFinal.getAbsolutePath();
                        iv_Imagen.setImageBitmap(BitmapFactory.decodeFile(url));
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(), "Imagen no encontrada", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
