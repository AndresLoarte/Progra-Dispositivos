package com.sc703.tiendaVirtual.ui.sqlite;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.sc703.tiendaVirtual.AdminBD;
import com.sc703.tiendaVirtual.R;

public class SQLiteFragment extends Fragment {

    private AdminBD estructura;
    private SQLiteDatabase db; //conexion a la base de datos



    private Button bn_Agregar, bn_Eliminar, bn_Editar, bn_BuscarSQL;
    private EditText et_NCedula, et_NCompleto,et_Direccion,et_Telefono;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_sqlite, container, false);

        estructura = new AdminBD(this.getContext(),"Cliente",null, 1);

        et_NCedula = root.findViewById(R.id.et_Cedula);
        et_NCompleto = root.findViewById(R.id.et_Nombre);
        et_Direccion = root.findViewById(R.id.et_Direccion);
        et_Telefono = root.findViewById(R.id.et_Telefono);


        bn_Agregar = root.findViewById(R.id.bn_Insertar);
        bn_BuscarSQL = root.findViewById(R.id.bn_Buscar);
        bn_Editar = root.findViewById(R.id.bn_Modificar );
        bn_Eliminar = root.findViewById(R.id.bn_Eliminar);


        bn_Agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Agregar();
            }
        });

        bn_Eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Eliminar();
            }
        });

        bn_Editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Editar();
            }
        });

        bn_BuscarSQL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Buscar();
            }
        });

        return root;
    }

    private void Agregar(){
        //nos da acceso para escribir en la BD
        db = estructura.getWritableDatabase();

        int Cedula = Integer.parseInt(et_NCedula.getText().toString());
        String Nombre = et_NCompleto.getText().toString();
        String Direccion = et_Direccion.getText().toString();
        String Telefono = et_Telefono.getText().toString();

        ContentValues contenedor = new ContentValues();
        contenedor.put("ID",Cedula);
        contenedor.put("Nombre",Nombre);
        contenedor.put("Direccion",Direccion);
        contenedor.put("Telefono",Telefono);


        db.insert("Cliente",null,contenedor);
        db.close();
        Toast.makeText(getContext(),"Datos agregados",Toast.LENGTH_SHORT).show();
    }

    private void Editar(){
        db = estructura.getWritableDatabase();

        int Cedula = Integer.parseInt(et_NCedula.getText().toString());
        String Nombre = et_NCompleto.getText().toString();
        String Direccion = et_Direccion.getText().toString();
        String Telefono = et_Telefono.getText().toString();

        ContentValues contenedor = new ContentValues();
        contenedor.put("ID",Cedula);
        contenedor.put("Nombre",Nombre);
        contenedor.put("Direccion",Direccion);
        contenedor.put("Telefono",Telefono);


        int n = db.update("Cliente",contenedor,"ID = " + Cedula,null);

        if(n == 1){
            Toast.makeText(getContext(),"Datos Modificados",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getContext(),"No se pudo modificar los Datos",Toast.LENGTH_SHORT).show();
        }
    }

    private void Eliminar(){
        db = estructura.getWritableDatabase();
        int Cedula = Integer.parseInt(et_NCedula.getText().toString());

        int n = db.delete("Cliente","ID = " + Cedula,null);

        if(n == 1){
            Toast.makeText(getContext(),"Datos Eliminado",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getContext(),"No se pudo Eliminar los Datos",Toast.LENGTH_SHORT).show();
        }
    }

    private void Buscar(){
        db = estructura.getReadableDatabase();
        int Cedula = Integer.parseInt(et_NCedula.getText().toString());

        Cursor fila = db.rawQuery("select * from Cliente where" + Cedula, null);
        if(fila.moveToFirst()){
            et_NCompleto.setText("" + fila.getString(1));
            et_Direccion.setText("" + fila.getString(2));
            et_Telefono.setText("" + fila.getString(3));

        }
    }

}

