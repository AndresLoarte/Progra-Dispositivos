package com.sc703.tiendaVirtual.ui.realtime;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.sc703.tiendaVirtual.R;

public class RealTimeFragment extends Fragment {

    TextView tv_realtime;
    FirebaseDatabase BD = FirebaseDatabase.getInstance();
    DatabaseReference ref = BD.getInstance().getReference();
    DatabaseReference Noticias = ref.child("Noticias");


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_realtime, container, false);

        tv_realtime = root.findViewById(R.id.tv_Realtime);
        return root;
    }

    @Override
    public void onStart() {
        super.onStart();

        Noticias.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String txt_Noticias = dataSnapshot.getValue().toString();
                tv_realtime.setText(txt_Noticias);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
