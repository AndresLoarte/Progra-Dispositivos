package com.sc703.tiendaVirtual;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private EditText et_Correo, et_Contrasena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

    }

    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    private void updateUI(FirebaseUser currentUser) {
        if (currentUser != null){
            Intent intent = new Intent(this, Principal.class);
            startActivity(intent);
        }else{Toast.makeText(getApplicationContext(), "Usuario no registrado. Registrese",
                Toast.LENGTH_LONG).show();

        }
    }

    public void Registro(View view){
        String Correo = et_Correo.getText().toString();
        String Contrasena = et_Contrasena.getText().toString();

        mAuth.createUserWithEmailAndPassword(Correo, Contrasena)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d("Reg", "Usuario Creado Exitosamente");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            Log.w("Registro", "Creacion de usuario Fallida", task.getException());
                            Toast.makeText(getApplicationContext(), "Creación de usuario fallida.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }
                    }
                });
    }

    public void Ingreso(View view){
        String Correo = et_Correo.getText().toString();
        String Contrasena = et_Contrasena.getText().toString();

        mAuth.signInWithEmailAndPassword(Correo, Contrasena)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d("Ingreso", "Ingreso Satisfactorio");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            Log.w("Ingreso", "Ingreso Fallido", task.getException());
                            Toast.makeText(getApplicationContext(), "Usuario no Registrado.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }
                    }
                });
    }
}