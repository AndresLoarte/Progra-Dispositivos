package com.sc703.tiendaVirtual.ui.salir;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.sc703.tiendaVirtual.MainActivity;
import com.sc703.tiendaVirtual.R;

public class SalirFragment extends Fragment {
    Button bt_Salir;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_salir, container, false);

        bt_Salir = root.findViewById(R.id.bt_Salir);

        bt_Salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();  //salir del Firebase
                Toast.makeText(getContext(),"Se ha desconectado del servidor",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);

            }
        });

        return root;
    }
}
